player1_name = localStorage.getItem("player1_name")
player2_name = localStorage.getItem("player2_name")


